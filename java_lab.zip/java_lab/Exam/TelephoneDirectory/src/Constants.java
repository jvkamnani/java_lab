public class Constants {
	protected static String host = "jdbc:mysql://localhost:3306/test";
    protected static String driver = "com.mysql.jdbc.Driver";
    protected static String user = "hemant";
    protected static String pass = "password"; 
}
