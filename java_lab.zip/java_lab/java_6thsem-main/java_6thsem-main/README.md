NOTE: The programs maynot be complete and maybe incorrect. 
... note the jdbc table parameters like int or varchar and pass accordingly and column names and all columns ... im lazy to add all columns 😁😅
# java_6thsem
Q2. Book
Q1. Telephone
Q3. Swings_Student
Q4. Swings_customer



Tutorial
Book swings
