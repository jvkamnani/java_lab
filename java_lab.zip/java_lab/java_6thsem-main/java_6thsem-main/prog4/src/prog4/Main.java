package prog4;

public class Main {
	public static void main(String[] args) {
		new ItemList();//init values in items
		new Login();
	}
}
