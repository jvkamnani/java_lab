package prog4;

import java.util.ArrayList;

public class ItemList {
	public static ArrayList<Item> itemList = new ArrayList<Item>();
	ItemList(){
		itemList.add(new Item(1,"Item1",10));
		itemList.add(new Item(2,"Item2",20));
		itemList.add(new Item(3,"Item3",30));
		itemList.add(new Item(4,"Item4",40));
		itemList.add(new Item(5,"Item5",50));
	}
}
