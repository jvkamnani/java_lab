package Phone;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContactList cl = new ContactList();
		missedCallList ml = new missedCallList();
		ml.viewLog();
		System.out.println("end of progm");
	}

}
