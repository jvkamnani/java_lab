package Phone;

public class Contacts {
	int num;String name;
	public Contacts(int n,String name) {
		this.num = n;
		this.name = name;
	}
}
