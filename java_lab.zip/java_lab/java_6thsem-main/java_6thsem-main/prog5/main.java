
public class main {
	public static void main(String args[]) {
		new connection();
		new rep();
		new customer();
	}
}
