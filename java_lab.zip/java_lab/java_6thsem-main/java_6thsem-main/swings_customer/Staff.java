package swings_customer;

public class Staff {
	String username,password;
	public Staff(String u,String p) {
		this.username = u;
		this.password = p;
	}
}
